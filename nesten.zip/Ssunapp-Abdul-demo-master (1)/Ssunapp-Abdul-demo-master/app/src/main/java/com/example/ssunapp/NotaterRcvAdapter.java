package com.example.ssunapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class NotaterRcvAdapter extends RecyclerView.Adapter<NotaterRcvAdapter.ViewHolder> {

    private List<Noter> originalList; // Original, unfiltered list of notes
    private List<Noter> filteredList; // Filtered list of notes
    private Context context;

    public NotaterRcvAdapter(List<Noter> noters, Context context) {
        this.originalList = new ArrayList<>(noters);
        this.filteredList = new ArrayList<>(noters); // Initially, filtered list is same as original
        this.context = context;
    }

    public void setNotes(ArrayList<Noter> newNotes) {
        this.originalList.clear();
        this.originalList.addAll(newNotes);
        this.filteredList.clear();
        this.filteredList.addAll(newNotes);
        notifyDataSetChanged();
    }



    public void filter(String text) {
        filteredList.clear();
        if (text.isEmpty()) {
            filteredList.addAll(originalList);
        } else {
            text = text.toLowerCase();
            for (Noter noter : originalList) {
                if (noter.getNoter_title().toLowerCase().contains(text)) {
                    filteredList.add(noter);
                }
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notat_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Noter noter = filteredList.get(position);
        holder.titleView.setText(noter.getNoter_title());
        holder.fagView.setText(noter.getNoter_fag());

        if (noter.getNoter_img() != null && !noter.getNoter_img().isEmpty()) {
            Glide.with(context).load(Uri.parse(noter.getNoter_img())).into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.notaking); // Replace with your placeholder image
        }
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView titleView, fagView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.cardv_img);
            titleView = itemView.findViewById(R.id.cardv_tv_title);
            fagView = itemView.findViewById(R.id.cardv_tv_section);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                Noter noter = filteredList.get(position);
                Intent intent = new Intent(context, NotatDetaljerActivity.class);
                intent.putExtra("NOTAT_ID", noter.getNoter_id());
                intent.putExtra("NOTAT_TITLE", noter.getNoter_title());
                intent.putExtra("NOTAT_FAG", noter.getNoter_fag());
                intent.putExtra("NOTAT_LARER", noter.getNoter_larer());
                intent.putExtra("NOTAT_BESKRIVELSE", noter.getNoter_des());
                intent.putExtra("NOTAT_BILDE", noter.getNoter_img());
                context.startActivity(intent);
            }
        }
    }
}
