package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import androidx.annotation.Nullable;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_FOR_NOTE_DETAILS = 2; // Or any other unique integer


    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private FloatingActionButton addButton;
    private NotaterRcvAdapter notaterRcvAdapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private DataBase sqlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupToolbar();
        setupRecyclerView();
        setupAddButton();
    }


    private void initializeViews() {
        toolbar = findViewById(R.id.main_activ_toolbar);
        recyclerView = findViewById(R.id.main_activ_rsv);
        addButton = findViewById(R.id.main_activ_fbut_addnot);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        swipeRefreshLayout.setOnRefreshListener(this::refreshNotater);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.main_activ_toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupRecyclerView() {
        sqlite = new DataBase(this);
        ArrayList<Noter> noters = sqlite.getAllnoters();
        notaterRcvAdapter = new NotaterRcvAdapter(noters, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(notaterRcvAdapter);
        recyclerView.setHasFixedSize(true);
    }

    private void setupAddButton() {
        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ViewNotActivity.class);
            startActivityForResult(intent, REQUEST_CODE_FOR_NOTE_DETAILS);

        });


    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshNotater();
    }

    private void refreshNotater() {
        ArrayList<Noter> updatedNoters = sqlite.getAllnoters();
        notaterRcvAdapter.setNotes(updatedNoters); // Update the adapter with new data
        notaterRcvAdapter.notifyDataSetChanged(); // Notify the adapter of data changes
        swipeRefreshLayout.setRefreshing(false);
    }
    private void signOut() {
        // Here you can clear any stored user data or preferences as needed

        // Navigate back to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        // Clear the back stack to prevent going back to MainActivity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_meny, menu);

        // Find the search item
        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        if (searchItem != null) {
            SearchView searchView = (SearchView) searchItem.getActionView();
            if (searchView != null) {
                // Set the listener for the SearchView
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        // Add your search logic here
                        notaterRcvAdapter.filter(query);
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // Update the search filter as the user types
                        notaterRcvAdapter.filter(newText);
                        return true;
                    }
                });
            } else {
                Toast.makeText(MainActivity.this, "Search View is not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Search item is not found in the menu", Toast.LENGTH_SHORT).show();
        }

        return true;
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_FOR_NOTE_DETAILS && resultCode == RESULT_OK) {
            refreshNotater(); // Refresh your notes list
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.details_meny_lagre) {
            // Handle save action
            return true;
        } else if (id == R.id.details_meny_rediger) {
            // Handle edit action
            return true;
        } else if (id == R.id.details_meny_slett) {
            // Handle delete action
            return true;
        } else if (id == R.id.menu_sign_out) {
            // Handle sign-out action
            signOut();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
