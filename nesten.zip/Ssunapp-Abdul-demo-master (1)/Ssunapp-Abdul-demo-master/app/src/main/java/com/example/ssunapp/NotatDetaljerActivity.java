package com.example.ssunapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class NotatDetaljerActivity extends AppCompatActivity {

    private EditText editTitle, editFag, editLarer, editDesc;
    private Button saveButton, editButton;
    private Noter currentNoter;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notat_detaljer);

        // Initialiser Views
        imageView = findViewById(R.id.imageView);
        editTitle = findViewById(R.id.editTitle);
        editFag = findViewById(R.id.editFag);
        editLarer = findViewById(R.id.editLarer);
        editDesc = findViewById(R.id.editDesc);
        saveButton = findViewById(R.id.saveButton);
        editButton = findViewById(R.id.editButton);

        // Hent data sendt fra MainActivity
        Intent intent = getIntent();
        currentNoter = new Noter(); // Anta at vi har en tom konstruktør
        currentNoter.setNoter_id(intent.getIntExtra("NOTAT_ID", -1));
        currentNoter.setNoter_title(intent.getStringExtra("NOTAT_TITLE"));
        currentNoter.setNoter_fag(intent.getStringExtra("NOTAT_FAG"));
        currentNoter.setNoter_larer(intent.getStringExtra("NOTAT_LARER"));
        currentNoter.setNoter_des(intent.getStringExtra("NOTAT_BESKRIVELSE"));
        currentNoter.setNoter_img(intent.getStringExtra("NOTAT_BILDE"));

        // Set data til visningskomponentene
        editTitle.setText(currentNoter.getNoter_title());
        editFag.setText(currentNoter.getNoter_fag());
        editLarer.setText(currentNoter.getNoter_larer());
        editDesc.setText(currentNoter.getNoter_des());

        // Last inn bildet med Glide
        if (currentNoter.getNoter_img() != null && !currentNoter.getNoter_img().isEmpty()) {
            Glide.with(this)
                    .load(Uri.parse(currentNoter.getNoter_img()))
                    .placeholder(R.drawable.notaking) // Erstatt med faktisk placeholder-bilde
                    .error(R.drawable.notaking) // Erstatt med faktisk feil-bilde
                    .into(imageView);
        }

        // Rediger-knappen
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                enableEditing();
            }
        });

        // Lagre-knappen
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveNote();
            }
        });

        // Tilbake-knappen
        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // Slette-knapp
        Button deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteNotat();
            }
        });
    }

    private void enableEditing() {
        editTitle.setEnabled(true);
        editFag.setEnabled(true);
        editLarer.setEnabled(true);
        editDesc.setEnabled(true);

        editTitle.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(editTitle, InputMethodManager.SHOW_IMPLICIT);

        saveButton.setVisibility(View.VISIBLE);
        editButton.setVisibility(View.GONE);
    }

    private void saveNote() {
        // Oppdater currentNoter med de nye verdiene fra EditText-feltene
        currentNoter.setNoter_title(editTitle.getText().toString());
        currentNoter.setNoter_fag(editFag.getText().toString());
        currentNoter.setNoter_larer(editLarer.getText().toString());
        currentNoter.setNoter_des(editDesc.getText().toString());

        // Lagre oppdateringene til databasen
        DataBase db = new DataBase(NotatDetaljerActivity.this);
        boolean result = db.updateNotat(currentNoter);

        if(result) {
            Toast.makeText(NotatDetaljerActivity.this, "Notatet er oppdatert", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        } else {
            Toast.makeText(NotatDetaljerActivity.this, "Kunne ikke oppdatere notatet", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteNotat() {
        DataBase db = new DataBase(NotatDetaljerActivity.this);
        boolean result = db.deleteNotat(currentNoter.getNoter_id());

        if(result) {
            Toast.makeText(NotatDetaljerActivity.this, "Notatet er slettet", Toast.LENGTH_SHORT).show();

            // Set the result before finishing
            setResult(RESULT_OK);

            finish(); // Lukker aktiviteten og returnerer til forrige skjerm
        } else {
            Toast.makeText(NotatDetaljerActivity.this, "Kunne ikke slette notatet", Toast.LENGTH_SHORT).show();
        }
    }

}
