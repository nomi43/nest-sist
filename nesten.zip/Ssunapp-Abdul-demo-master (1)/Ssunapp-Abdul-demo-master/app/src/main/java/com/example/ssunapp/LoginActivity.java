package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {


    EditText et_usermail, et_password;
    Button btn_sign, btn_signup;
    private void signOut() {
        // Clear any user-specific data here if needed

        // Navigate back to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        finish(); // This will remove MainActivity from the back stack
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        DataBase dbsqlite = new DataBase(this);

        et_usermail = findViewById(R.id.login_et_mail);
        et_password = findViewById(R.id.login_et_pass);

        btn_signup = findViewById(R.id.login_btn_signup);
        btn_sign= findViewById(R.id.login_btn_sign);


        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String mail_login=et_usermail.getText().toString().trim();
                if(mail_login.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Email field is empty, try Again", Toast.LENGTH_SHORT).show();
                }
                String pass_login=et_password.getText().toString().trim();
                if(pass_login.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Password field is empty, try Again", Toast.LENGTH_SHORT).show();
                }

                boolean res_login=dbsqlite.login_user(mail_login,pass_login);
                if (res_login){

                    Toast.makeText(getApplicationContext(), "login Successful", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);

                }else {
                    Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });



        btn_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), RegActivity.class);
                startActivity(intent);

            }
        });


    }

}
